from .models import mysite

fields = mysite.objects.values('id','username','email','password','last_modify_date','created')

def list_all():
    result = fields.order_by('id', 'created')
    return list(result) 
    
def list_filter(data):
    result = fields.order_by('id', 'created')
    # 如果 filters 字典中包含 'username' 鍵且值不為空
    if 'username' in data and data['username']:
        result = result.filter(username__icontains=data['username'])
    if 'email' in data and data['email']:
        result = result.filter(email__icontains=data['email'])
    return list(result)

def find_by_username(data):
    result = fields.filter(username__icontains=data['username']).values('username')
    return list(result)

def insert(data):
    mysite.objects.create(**data)
    return 

def update(id, data):
    
    try:
        # 取得要更新的 Mysite 物件
        mysite_entry = mysite.objects.get(id=id)

        # 更新欄位
        for field, value in data.items():
            setattr(mysite_entry, field, value)

        # 保存更新
        mysite_entry.save()

        return True
    except mysite.DoesNotExist:
        # 若找不到指定 id 的 Mysite 物件
        return False