import subprocess
from django.http import HttpResponse
import os

# 將 'jasperstarter' 所在的整個 'bin' 目錄添加到 PATH
os.environ['PATH'] = '/home/vboxuser/demo/jasperstarter/bin:' + os.environ['PATH']

def generate_report(request):
    # 指定jrxml文件的路徑
    jrxml_path = '/home/vboxuser/JaspersoftWorkspace/MyReports/Blank_A4_1.jrxml'

    # 指定生成的PDF文件的路徑和名稱（刪除.pdf擴展名）
    pdf_output_path = '/home/vboxuser/Downloads/output'

    # 設置參數（如果有的話）
    # params = {
    #     'param1': 'value1',
    #     'param2': 'value2',
    #     # 添加任何其他參數
    # }

    # JDBC 连接字符串（使用 PostgreSQL）
    jdbc_url = 'jdbc:postgresql://127.0.0.1:5432/mysite'
    jdbc_username = 'postgres'
    jdbc_password = 'admin'

    # 構建JasperReports命令
    # 構建JasperReports命令
    # 構建JasperReports命令
    
    
    jasper_cmd = [
        '/home/vboxuser/demo/jasperstarter/bin/jasperstarter',
        'pr',  # 使用 'pr' 命令來處理報告
        jrxml_path,
        '-o', pdf_output_path,
        '-f', 'pdf',
        '-t','postgres',
        '-H','127.0.0.1',
        '-u', 'postgres',
        '-p', 'admin',
        '-n', 'mysite',
        '--db-port', '5432',
        '--db-driver','org.postgresql.Driver',
        '--db-url',jdbc_url,
        '--jdbc-dir','/home/vboxuser/demo/jasperstarter/jdbc',
        '--data-file', '/home/vboxuser/demo/django1/mysite/query-file.sql',
    ]




    # 添加參數
    # for key, value in params.items():
    #     jasper_cmd.extend(['-P', f'{key}={value}'])

    # 執行命令
    result = subprocess.run(jasper_cmd)
    print(result)

    # 將生成的PDF文件返回給用戶
    try:
        with open(pdf_output_path + '.pdf', 'rb') as pdf_file:
            response = HttpResponse(pdf_file.read(), content_type='application/pdf')
            response['Content-Disposition'] = 'inline; filename="output.pdf"'
            return response
    except FileNotFoundError:
        return HttpResponse("Error: Report file not found.")
