import subprocess

def add_cron_job():
    """
    動態增加 cron 作業
    """
    cron_command = "python manage.py crontab add"
    subprocess.run(cron_command, shell=True)

def remove_cron_job():
    """
    動態移除 cron 作業
    """
    cron_command = '(crontab -l | grep -v "python manage.py crontab remove") | crontab -'
    subprocess.run(cron_command, shell=True)

# 示例：每天中午執行一次 my_command


# 示例：移除名稱為 my_command 的 cron 作業
remove_cron_job()

