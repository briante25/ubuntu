from mysite import UserResource
def txcode(txcode,message):
    if txcode=='BASIC_USER_LIST_ALL':
        return UserResource.decodecontent(txcode,message)
    
    elif txcode=='BASIC_USER_LIST_FILTER':      
        return UserResource.decodecontent(txcode,message)
    
    elif txcode=='BASIC_USER_FIND_BY_USERNAME':
        return UserResource.decodecontent(txcode,message)
    
    elif txcode=='BASIC_USER_INSERT':
        return UserResource.decodecontent(txcode,message)
    
    elif txcode=='BASIC_USER_UPDATE':
        return UserResource.decodecontent(txcode,message)
    else:
        return "未定義的txcode"
