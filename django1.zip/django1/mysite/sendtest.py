from mysite.models import mysite
from django.shortcuts import render, redirect
from django.db import connection
from mysite.sendtest1 import selecttest1


def send1(request):
    data = {
        'txcode': 'BASIC_USER_INSERT',
        'username': '123',
        'email': '123',
        'password': ''
    }   
    #selecttest1(data)
    selecttest(data)
    return render(request, 'registration/success.html')
    
def check(data):
    if data['txcode'] == 'BASIC_USER_INSERT':
        mysite(username=data['username'],email=data['email'],password=data['password']).save()

def selecttest(data):
    base_query = 'SELECT * FROM public.mysite'
    final_query = base_query
    params = []

    if data['username'] != '':
        final_query += ' WHERE username ILIKE %s'
        params.append(f"%{data['username']}%")

    if data['email'] != '':
        if data['username'] != '':
            final_query += ' AND email ILIKE %s'
        else:
            final_query += ' WHERE email ILIKE %s'
        params.append(f"%{data['email']}%")

    if data['password'] != '':
        if data['username'] != '' or data['email'] != '':
            final_query += ' AND password ILIKE %s'
        else:
            final_query += ' WHERE password ILIKE %s'
        params.append(f"%{data['password']}%")

    raw_queryset = mysite.objects.raw(final_query, params)
    printresult(raw_queryset, params)

def printresult(raw_queryset, params):
    # Accessing the values of each row (if any)
    for row in raw_queryset:
        username_value = row.username
        email_value = row.email
        password_value = row.password
        print(f'Username: {username_value} Email: {email_value} Password: {password_value}')
        # Access other fields in a similar manner

        # Do something with the values (e.g., print or return)

    # Print the params and raw_queryset outside the loop
    print("Params:", params)
    print("Raw Queryset:", raw_queryset)


    