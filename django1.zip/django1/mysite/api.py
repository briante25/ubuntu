import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .check import check
@csrf_exempt
def apitest(request):
    if request.method == 'POST':
        try:
            # 從請求主體中讀取JSON數據
            json_data = json.loads(request.body.decode('utf-8'))
            
            # 調用 .txcode 模塊中的 check 函數
            result = check(json_data)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
            # 使用 JsonResponse 返回 JSON 格式的數據
            return result
        except json.JSONDecodeError as e:
            return JsonResponse({'error': 'Invalid JSON format'}, status=400)
        
    else:
        return JsonResponse({'error': 'Invalid method'}, status=400)