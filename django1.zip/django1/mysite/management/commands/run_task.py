from django.core.management.base import BaseCommand
from mysite.task import my_scheduled_task

class Command(BaseCommand):
    help = 'Run scheduled task'

    def handle(self, *args, **options):
        my_scheduled_task()