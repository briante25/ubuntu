from django.http import JsonResponse
from .sql import *
from .valid import *
from .models import mysite
fields={
    "username":"",
    "email":"",
}

def doTransaction(txcode,message):
    match txcode:
        case 'BASIC_USER_LIST_ALL':
            return listAll()        
        case 'BASIC_USER_LIST_FILTER':
            return listFilter(fields)       
        case 'BASIC_USER_FIND_BY_USERNAME':
            return Findbycode(fields)
        case 'BASIC_USER_INSERT':
            return Insert(message)        
        case 'BASIC_USER_UPDATE':
            return Update(message)

def decodecontent(txcode,message):
    match txcode:
        case 'BASIC_USER_LIST_ALL':
            return encodecontent(txcode,message)                  
        case 'BASIC_USER_LIST_FILTER':
            if "username" in message:
                fields["username"]=message["username"]
            else:
                fields["usernaame"]=""

            if "email" in message:
                fields["email"]=message["email"]
            else:
                fields["email"]=""
            return encodecontent(txcode,fields)       
        case 'BASIC_USER_FIND_BY_USERNAME':
            if "username" in message:
                fields["usernaame"]=message["username"]
            else:
                fields["usernaame"]=""
            return encodecontent(txcode,fields["username"])        
        case 'BASIC_USER_INSERT':
            if "username" not in message:
                return JsonResponse({'error': '缺少username'}, status=400)            
            if "email" not in message:
                return JsonResponse({'error': '缺少email'}, status=400)            
            if "password" not in message:
                return JsonResponse({'error': '缺少password'}, status=400)
            return encodecontent(txcode,message)       
        case 'BASIC_USER_UPDATE':
            if "id" not in message:
                return JsonResponse({'error': '缺少id'}, status=400)
            if "username" not in message:
                return JsonResponse({'error': '缺少username'}, status=400)            
            if "email" not in message:
                return JsonResponse({'error': '缺少email'}, status=400)            
            if "password" not in message:
                return JsonResponse({'error': '缺少password'}, status=400)
            return encodecontent(txcode,message)
    

def encodecontent(txcode,message):
    match txcode:
        case 'BASIC_USER_LIST_ALL':
            data=doTransaction(txcode,message)
            return JsonResponse({"message":{'data': data}},safe=False)           
        case 'BASIC_USER_LIST_FILTER':
            data=doTransaction(txcode,message)
            return JsonResponse({"message":{'data': data}},safe=False)
        case 'BASIC_USER_FIND_BY_USERNAME':
            data=doTransaction(txcode,message)
            return JsonResponse({"message":{'data': data}},safe=False)        
        case 'BASIC_USER_INSERT':
            data=doTransaction(txcode,message)
            return data
        case 'BASIC_USER_UPDATE':
            data=doTransaction(txcode,message)
            return data 

def listAll():
    return list_all()

def listFilter(fields):
    return list_filter(fields)

def Findbycode(fields):
    return find_by_username(fields)

def Insert(message):
    if mysite.objects.filter(username=message["username"]).exists():
        return JsonResponse({'error': 'username已存在'}, status=400,safe=False)
    elif mysite.objects.filter(email=message["email"]).exists():
        return JsonResponse({'error': 'email已存在'}, status=400)
    elif valid_string(message["username"])==False:
        return JsonResponse({'error': 'username格式錯誤'}, status=400)
    elif valid_email(message["email"])==False:
        return JsonResponse({'error': 'email格式錯誤'}, status=400)
    elif valid_password(message["password"])==False:
        return JsonResponse({'error': 'password格式錯誤'}, status=400)
    else:
        insert(message)
        return JsonResponse({'Insert': '新增成功'}, status=200) 
    
def Update(message):
        mysite_entry = mysite.objects.get(id=message["id"])

        for key, value in message.items():
            setattr(mysite_entry, key, value)

        mysite_entry.save()
        return JsonResponse({'Update': '修改成功'}, status=200)
