from django.http import JsonResponse
from .txcode import *

def check(data):
    header=data["header"]
    message=data["message"]
    if 'txcode' not in header:
        return JsonResponse({'error': '缺少txcode'}, status=400)
    elif header['txcode'] == '':                
        return JsonResponse({'error': 'txcode無內容'}, status=400)
    else:
        return txcode(header["txcode"],message)