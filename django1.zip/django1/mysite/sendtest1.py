from django.db.models import Q
from itertools import chain
from mysite.models import mysite

def selecttest1(data):
    query = Q()
    
    if data['username'] != '':
        query |= Q(username__icontains=data['username'])

    if data['email'] != '':
        query |= Q(email__icontains=data['email'])

    if data['password'] != '':
        query |= Q(password__icontains=data['password'])

    rqueryset1 = mysite.objects.filter(query).values('username', 'email')
    queryset2 = mysite.objects.filter(query).values('username', 'password')
    queryset3 = mysite.objects.filter(query).values('email', 'password')

    # Combine the querysets
    combined_queryset = list(chain(rqueryset1, queryset2, queryset3))

    for row in combined_queryset:
        username_value = row.get('username', '')
        email_value = row.get('email', '')
        password_value = row.get('password', '')
        print(f'Username: {username_value} Email: {email_value} Password: {password_value}')

    
# 使用示例


